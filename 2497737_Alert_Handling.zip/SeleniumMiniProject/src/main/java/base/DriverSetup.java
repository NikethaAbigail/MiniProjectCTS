package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;


public class DriverSetup {

    public static WebDriver driver;
    public static WebDriver setUpDriver(String browser) {

        switch (browser.toLowerCase()) {
            case "chrome":
                driver = new ChromeDriver();
                break;
            case "edge":

                System.setProperty("webdriver.edge.driver","C:\\Drivers\\msedgedriver.exe");

                driver = new EdgeDriver();
                break;
            default:
                System.out.println("Invalid Browser");
                break;
        }
        driver.manage().window().maximize();
        return driver;
    }

    public static void closeBrowser(){
        if(driver != null){
            driver.quit();
        }
    }
}
