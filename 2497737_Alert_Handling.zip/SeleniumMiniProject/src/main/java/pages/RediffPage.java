package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RediffPage {

    WebDriver driver;
    public RediffPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver,this);
    }
    @FindBy(linkText = "Sign in") WebElement signInLink;
    @FindBy(name="proceed") WebElement signInButton;
    @FindBy(linkText ="Forgot password?") WebElement forgotPasswordLink;
    @FindBy(name="next") WebElement nextButton;
    @FindBy(linkText = "Privacy Policy") WebElement privacyPolicy;

    public void clickSignInLink(){
        signInLink.click();
    }

    public void clickSignInButton(){
        signInButton.click();
    }

    public void clickForgotPassword(){
        forgotPasswordLink.click();
    }

    public void clickNextButton(){
        nextButton.click();
    }

    public void clickPrivacyPolicy() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();",privacyPolicy);
    }
}
