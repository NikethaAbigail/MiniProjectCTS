package utilities;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

public class AlertUtils {
    public static String getAlertText(WebDriver driver){
        Alert alert=driver.switchTo().alert();
        return alert.getText();
    }

    public static void acceptAlert(WebDriver driver){
        Alert alert=driver.switchTo().alert();
        alert.accept();
    }

}
