package utilities;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;

public class ScreenShotUtils {

    public static void takeScreenshot(WebDriver driver, String fileName) {

        TakesScreenshot ts = (TakesScreenshot) driver;

        File sourceFile = ts.getScreenshotAs(OutputType.FILE);

        File destinationFile = new File(
                "screenshots/" + fileName + ".png"
        );

        try {

            FileUtils.copyFile(sourceFile, destinationFile);

            System.out.println("Screenshot saved: " + destinationFile.getAbsolutePath());

        } catch (IOException e) {

            System.out.println("Failed to save screenshot: " + e.getMessage());
        }
    }
}