package utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class WaitUtils {

    public static WebDriverWait getWait(WebDriver driver) {

        return new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public static void waitTime() {

        try {

            Thread.sleep(1000);

        } catch (InterruptedException e) {

            System.out.println("Wait interrupted: " + e.getMessage());
        }
    }
}