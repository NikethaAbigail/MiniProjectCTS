package tests;

import base.DriverSetup;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import pages.RediffPage;
import utilities.AlertUtils;
import static utilities.WaitUtils.waitTime;

public class AlertTest {

    WebDriver driver;
    RediffPage rediffPage;

    @BeforeClass
    @Parameters("browser")
    public void setUp(String browser) {

        driver = DriverSetup.setUpDriver(browser);
        driver.get("https://mail.rediff.com/");
        rediffPage = new RediffPage(driver);
    }

    @Test(priority = 1)
    public void alertTest(){
        try {
            rediffPage.clickSignInLink();
            rediffPage.clickSignInButton();
            String firstAlert = AlertUtils.getAlertText(driver);
            System.out.println(firstAlert);
            waitTime();
            AlertUtils.acceptAlert(driver);


            rediffPage.clickForgotPassword();
            rediffPage.clickNextButton();
            waitTime();

            String secondAlert = AlertUtils.getAlertText(driver);
            System.out.println(secondAlert);
            AlertUtils.acceptAlert(driver);
            driver.navigate().back();


        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        }

    }

    @Test(priority = 2)
    public void privacyPolicyTest(){
        try {

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
            waitTime();

            String parentWindow = driver.getWindowHandle();
            rediffPage.clickPrivacyPolicy();
            waitTime();

            for (String window : driver.getWindowHandles()) {
                if (!window.equals(parentWindow)) {
                    driver.switchTo().window(window);
                    waitTime();
                    System.out.println(driver.getTitle());
                }
            }
            driver.switchTo().window(parentWindow);
        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        }
    }

    @AfterClass
    public void tearDown() {
        DriverSetup.closeBrowser();
    }


}